// Put your applicaiton javascript here
$(document).ready(function(){

    // Free Shipping Threshold
    const fixedShippingPrice = 500.00;

    // Menu Drawer 
    const toggleTag = $('#header-global a.toggle-nav');   
    const eveToggleTag = $('.mobileToggle');
    const drawerBodyTag = $('body');
    const mainTag = $('main');

    
    toggleTag.click(function(){
        mainTag.toggleClass('open');
        drawerBodyTag.toggleClass('drawer-open');
    });

    eveToggleTag.click(function(){
        mainTag.toggleClass('open');
        drawerBodyTag.toggleClass('drawer-open');
    });

    // Closing Mini-Cart on clicking on body section
    const htmlTag = $('html');
    const bodyTag = $('#no-click');
    //let mainMiniCart = $('html.mini-cart-open #no-click').hide(200);
    bodyTag.click(function() {
        htmlTag.toggleClass('mini-cart-open');
    });


    // Add to cart form
    let 
        addToCartToCartFormSelector = '#add-to-cart-form',
        productOptionSelector = addToCartToCartFormSelector + ' [name*=option]';

    // create the object full of functions
    let productForm = {
        onProductOptionChanged: function(event){
            let
                $form = $(this).closest(addToCartToCartFormSelector),
                selectedVariant = productForm.getActiveVariant($form);
            
            $form.trigger('form:change', [selectedVariant]);            
            // console.log(selectedVariant);
        },
        getActiveVariant: function($form){
            let
                // Getting all variants by decoding the current Products to make it readable in JASON format
                variants = JSON.parse(decodeURIComponent($form.attr('data-variants'))),
                // Saving all the data that are in the form in formData Variable
                formData = $form.serializeArray(),
                formOptions = {
                    option1: null,
                    option2: null,
                    option3: null
                },                
                selectedVariant = null;

                $.each(formData, function(index, item){
                    // Check if the "name" attribute of the form contains value of "option" or not
                    if(item.name.indexOf('option') !== -1){
                        formOptions[item.name] = item.value;
                    }
                })                
                // Getting selected product variants
                $.each(variants, function(index, variant) {
                    if (variant.option1 === formOptions.option1 && variant.option2 === formOptions.option2 && variant.option3 === formOptions.option3) {
                        // console.log("Variants Matched");
                        selectedVariant = variant;     
                        return false;                   
                    }
                });
                //console.log(variants);
                //console.log(formOptions);
                return selectedVariant;

        },
        validate: function(event, selectedVariant){
            let
                $form = $(this),
                hasVariant = selectedVariant !== null,
                canAddToCart = hasVariant && selectedVariant.inventory_quantity > 0,
                $id = $form.find('.js-variant-id'),
                $addToCartButton = $form.find('#add-to-cart-button'),
                $price = $form.find('.js-price'),
                $oldPrice = $form.find('.js-old-price'),
                formattedVariantNewPrice,
                formattedVariantOldPrice,
                $selectSize = $form.find('.select_size_msg'),
                $outOfStock = $form.find('.out_of_stock'),
                $addToCart = $form.find('.quantity_selector'),
                priceHtml,
                oldPriceHtml;

                console.log(hasVariant);

                if (hasVariant) {
                    formattedVariantOldPrice = '$' + (Math.floor(selectedVariant.compare_at_price/100));
                    $oldPrice.html(formattedVariantOldPrice);
                    formattedVariantNewPrice = '$' + (Math.floor(selectedVariant.price/100));
                    priceHtml = '<span class="money">' + formattedVariantNewPrice + '</span>';
                    console.log(formattedVariantNewPrice);

                    window.history.replaceState(null, null, '?variant=' +selectedVariant.id);
                    console.log(selectedVariant.id);

                }else{
                    priceHtml = $price.attr('data-default-price');
                }

                if (canAddToCart) {
                    $id.val(selectedVariant.id);
                    $addToCartButton.prop('disabled', false);
                    console.log("Button has been enabled");

                    if (selectedVariant.sku === "VARIANTSELECT" || selectedVariant.sku === "GIFTSELECT" || selectedVariant.sku === "OFFERSELECT" ) {
                        $selectSize.show();
                        $addToCart.hide();
                        $outOfStock.hide();
                    }else{
                        $selectSize.hide();
                        $addToCart.show();
                        $outOfStock.hide();
                    }
                }
                else{
                    $id.val('');
                    $addToCartButton.prop('disabled', true);
                    console.log("Button has been disabled");

                    $selectSize.hide();
                    $addToCart.hide();
                    $outOfStock.show();
                }

                $price.html(priceHtml);
                console.log(selectedVariant);
                
            // To change the slider image based on variant selection
            // var variantID = selectedVariant["id"];
            //console.log(variantID);
            // var slickindex = $("body").find("[data-variant='" + variantID + "']").parent().data("slick-index"); 
            //console.log(slickindex);
            //console.log(variantID.);
            //console.log($(this).attr('name'));
            
            // let newNavTag = $('.nav-img').find(variantID);
            // console.log(newNavTag);
            // // console.log(newNavTag.attr('data-slick-index'));

            // $(".slider-nav").slick('slickGoTo', slickindex);
            // console.log($('.product-images .slick-active').attr('data-slick-index'));
            
        },
        init: function(){
            $(document).on('change', productOptionSelector, productForm.onProductOptionChanged);
            $(document).on('form:change', addToCartToCartFormSelector, productForm.validate);
        }
    }

    productForm.init();

    // Ajax API Functionality
    let miniCartContentsSelector = '.js-global-cart';

    let ajaxify = {
        onAddToCart: function(event){
            event.preventDefault();
            $.ajax({
                type: 'POST',
                url: '/cart/add.js',
                data: $(this).serialize(),
                dataType: 'json',
                success: ajaxify.onCartUpdated,
                error: ajaxify.onError
            });
        },
        onCartUpdated: function() {
            let 
                $miniCartFieldset = $(miniCartContentsSelector + ' .js-cart-fieldset');
                
                // Disable the button for top mini cart when '+' or '-' button has been clicked
                //$miniCartFieldset.prop('disabled', true);

            $.ajax({
                type: 'GET',
                url: '/cart',
                context: document.body,
                success: function(context) {
                    let
                        $dataCartContents = $(context).find('.js-cart-page-contents'),
                        dataCartHtml = $dataCartContents.html(),
                        dataCartPrice = $dataCartContents.find('.js-cart-subtotal'),
                        dataCartItemCount = $dataCartContents.attr('data-cart-item-count'),
                        $miniCartContents = $(miniCartContentsSelector),
                        $miniQuantity = $('.js-cart-mini-subtotal'),
                        $cartItemCount = $('.js-cart-item-count');
                    
                    $cartItemCount.text(dataCartItemCount);
                    $miniCartContents.html(dataCartHtml);

                    // update right hand side sub-total price based on the left hand sub-total price    
                    let 
                        compareShippingPrice = dataCartPrice.text().substring(1),
                        percentageBarValue = $('.js-progressbar-percentage');
                    
                    $miniQuantity.html(dataCartPrice.html()); 

                    // To reload the cart page when item gets empty
                    console.log(compareShippingPrice);
                    // console.log(window.location.href.indexOf('/cart'));
                    if (compareShippingPrice <= 0) {
                        //location.reload();
                    }

                    let remainingShippingFree = (((fixedShippingPrice - compareShippingPrice)/fixedShippingPrice)*100);
    
                    newRemainingProgressBar = 100 - remainingShippingFree;       
                    let totalPercentageBar = (Math.round(100 - remainingShippingFree) + '%');

                    // console.log('Compare Shipping Price: ' + compareShippingPrice);
                    // console.log('Fixed Shipping Price: ' + fixedShippingPrice.toFixed(2));

                    if (compareShippingPrice < fixedShippingPrice) {
                        //fixedShippingPrice - compareShippingPrice;
                        let priceLeftForFreeShipping = fixedShippingPrice - compareShippingPrice;
                        console.log('Price Left ' + priceLeftForFreeShipping.toFixed(2));
                        $('#price-left-for-free-shipping').html(priceLeftForFreeShipping.toFixed(2));
    
                        $('.js-cart-congratulation-hide').hide(100);
                        $('.js-cart-progress-bar').show(100);
                    }else{
                        $('.js-cart-congratulation-hide').show();
                        $('.js-cart-progress-bar').hide(100);
                    }

                    // console.log(newRemainingProgressBar);
                    // console.log((100 - remainingShippingFree) + '%');

                    if (newRemainingProgressBar > 0 && newRemainingProgressBar < 100) {
                        $('.js-progressbar-percentage.customwidth').css("width", totalPercentageBar);
                        $('.js-progressbar-percentage').html(totalPercentageBar);

                        $('.js-cart-congratulation-hide').hide(100);
                        $('.js-cart-progress-bar').show(100);
                    }else{                      
                        $('.js-cart-congratulation-hide').show(100);
                        $('.js-cart-progress-bar').hide(100);
                    }                   

                    if(parseInt(dataCartItemCount) > 0){
                        let isInCart = window.location.href.indexOf('/cart') !== -1;
                        if (!isInCart) {
                            ajaxify.openCart();
                        }
                    }else{
                        ajaxify.closeCart();
                    }
                }
            });
        },
        onError: function(XMLHttpRequest, textStatus) {
            let data = XMLHttpRequest.responseJSON;
            alert(data.status + ' - ' + data.message + ': ' + data.description);
        },
        onCartButtonClick: function(event) {
            let 
                isCartOpen = $('html').hasClass('mini-cart-open');
                // To check if we are in the cart page or not
                isInCart = window.location.href.indexOf('/cart') !== -1;

            if (!isInCart) {
                event.preventDefault();
                if (!isCartOpen) {
                    ajaxify.openCart();
                }else{
                    ajaxify.closeCart();
                }    
            }

        },
        openCart: function() {
            $('html').addClass('mini-cart-open');  
        },
        closeCart: function(params) {
            $('html').removeClass('mini-cart-open');
        },
        init: function () {
            $(document).on('submit', addToCartToCartFormSelector, ajaxify.onAddToCart);
            // $(document).on('click', "#mini-cart .js-remove-line", ajaxify.onLineRemoved);
            $(document).on('click', '.js-cart-link', ajaxify.onCartButtonClick);

        }
    };

    ajaxify.init();


    // Quantity Fields for Cart page
    let 
        quantityFieldSelector = '.js-quantity-field',
        quantityButtonSelector = '.js-quantity-button',
        quantityPickerSelector = '.js-quantity-picker',

        quantityPicker = {
            onButtonClick: function (event) {
                let
                    $button = $(this),
                    $picker = $button.closest(quantityPickerSelector),
                    $quantity = $picker.find('.js-quantity-field'),
                    quantityValue = parseInt($quantity.val()),
                    max = $quantity.attr('max') ? parseInt($quantity.attr('max')) : null;

                //console.log($(this));
                
                if ($button.hasClass('add') && (max === null || quantityValue+1 <= max)) {
                    // do something for plus click
                    // $quantity = parseInt(quantityValue + 1);
                    //console.log($quantity.val());
                    $quantity.val(quantityValue + 1).change();
                }
                else if($button.hasClass('sub')){
                    // do something for minus click
                    // $quantity = parseInt(quantityValue - 1);
                    $quantity.val(quantityValue - 1).change();
                    //$miniQuantity.val(quantityValue);
                    //console.log(quantityValue);
                }        
            },
            onChange: function(event) {
                let
                    $field = $(this),
                    $picker = $field.closest(quantityPickerSelector),
                    $quantityText = $picker.find('.js-quantity-text'),
                    shouldDisableMinus = parseInt(this.value) === 1,
                    shouldDisablePlus = parseInt(this.value) === parseInt($field.attr('max')),
                    $minusButton = $picker.find('.js-quantity-button.minus'),
                    $quantity = $('.js-cart-subtotal').html(),
                    quantityValue = $('.js-cart-mini-subtotal'),
                    $plusButton = $picker.find('.js-quantity-button.plus');
                
                $quantityText.text(this.value);
        
                if (shouldDisableMinus) {
                    $minusButton.prop('disabled', true);
                }
                else if($minusButton.prop('disabled') === true){
                    $minusButton.prop('disabled', false);
                }
        
                if (shouldDisablePlus) {
                    $plusButton.prop('disabled', true);
                }
                else if($plusButton.prop('disabled') === true){
                    $plusButton.prop('disabled', false);
                }    
                

            },
            init: function() {
                $(document).on('click', quantityButtonSelector, quantityPicker.onButtonClick);
                $(document).on('change', quantityFieldSelector, quantityPicker.onChange);       
            }
        };

    quantityPicker.init();


    // Line Item - Mini Cart Ajax for increament and decreament 
    let
        removeLineSelector = '.js-remove-line',
        lineQuantitySelector = '.js-line-quantity';

    let lineItem = {
        isInMiniCart: function(element) {
            let
                $element = $(element),
                $miniCart = $element.closest(miniCartContentsSelector),
                isInMiniCart = $miniCart.length !== 0;
            
            return isInMiniCart;            
        },
        onLinequantityChanged: function(event) {
            let
                quantity = this.value,
                id = $(this).attr('id').replace('updates_', ''),
                changes = {
                    quantity: quantity,
                    id: id
                }
                
                // console.log(changes);

                isInMiniCart = lineItem.isInMiniCart(this);
            
            // It will auto update the cart quantity after clicking increment and decrement button
            $.post('/cart/change.js', changes, ajaxify.onCartUpdated, 'json'); 
            
            // if (isInMiniCart) {
            //     $.post('/cart/change.js', changes, ajaxify.onCartUpdated, 'json');       
            // }
        },
        onLineRemoved: function(event) {
            let isInMiniCart = lineItem.isInMiniCart(this);
            if (isInMiniCart) {     
                event.preventDefault();

                let 
                    $removeLink = $(this),
                    removeQuery = $removeLink.attr('href').split('change?')[1];
                $.post('/cart/change.js', removeQuery, ajaxify.onCartUpdated, 'json');
            }
        },
        init: function() {
            $(document).on('click', removeLineSelector, lineItem.onLineRemoved);
            $(document).on('change', lineQuantitySelector, lineItem.onLinequantityChanged);
        }
    };

    lineItem.init();



    // Homepage Slideshow
    // let
    //     slidesSelector = '.js-slides',
    //     prevButtonSelector = '.js-slider-button-prev',
    //     nextButtonSelector = '.js-slider-button-next',
    //     sectionSlideshowSelector = '.js-section-slideshow',
    //     sectionSlideshows = {
    //         setup: function($element) {
    //             let 
    //                 $slides = $element.find(slidesSelector),
    //                 shouldAutoplay = $element.attr('data-autoplay') === 'true',
    //                 autoplaySpeed = parseInt($element.attr('data-autoplay-speed')),
    //                 $prevButton = $element.find(prevButtonSelector),
    //                 $nextButton = $element.find(nextButtonSelector),
    //                 sectionSlideshowOptions = {
    //                     fade: true,
    //                     nextArrow: $nextButton,
    //                     prevArrow: $prevButton,
    //                     autoplay: shouldAutoplay,
    //                     autoplaySpeed: autoplaySpeed
    //                 };
                
    //             $slides.slick(sectionSlideshowOptions);
                
    //         },
    //         init: function() {
    //             $(sectionSlideshowSelector).each(function() {
    //                 sectionSlideshows.setup($(this));
    //             })
    //         }
    //     };
    
    //     console.log(sectionSlideshowSelector);
    //     sectionSlideshows.init();



    // Product Page - Click event for quantity selector
    $(document).on('click', '.js-quantity-product-button', function(event) {
        console.log('Quantity selector button clicked');
        let
            $button = $(this),
            $form = $button.closest('form'),
            $quantity = $form.find('.js-quantity-product-field'),
            quantityValue = parseInt($quantity.val());
        
        if ($button.hasClass('plus')) {
            $quantity.val(quantityValue + 1).change(); 
        }else if($button.hasClass('minus')){
            $quantity.val(quantityValue -1).change();
        }             
    })

    // Product Page - Enable/Disable '-' button if the value is euqal to '1'
    $(document).on('change', '.js-quantity-product-field', function(event) {
        console.log('Quantity selector button changed');
        let
            $field = $(this),
            $form = $field.closest('form'),
            shouldDisableMinus = parseInt(this.value) === 1, 
            $minusButton = $form.find('.js-quantity-product-button.minus');
        
        if (shouldDisableMinus) {
            $minusButton.prop('disabled', true);
        }else{
            $minusButton.prop('disabled', false);
        }
    });



    // Slick Slider
    $('.slides').slick({
        lazyLoad: 'ondemand',
        mobileFirst: true,
        infinite: true,
        slidesToShow: 1,
        slidesToScroll: 1,
        autoplay: false,
        fade: true,
        speed: 500,
        prevArrow:"<img class='a-left control-c prev slick-prev' src='https://cdn.shopify.com/s/files/1/0098/8915/3081/files/icon-arrow-left.svg?v=1600149723'>",
        nextArrow:"<img class='a-right control-c next slick-next' src='https://cdn.shopify.com/s/files/1/0098/8915/3081/files/icon-arrow-right.svg?v=1600149723'>",
        asNavFor: '.slider-nav'
    });
    $('.slider-nav').slick({
        lazyLoad: 'ondemand',
        slidesToShow: 1,
        slidesToScroll: 1,
        asNavFor: '.slides',
        centerMode: false,
        focusOnSelect: true,
        arrows: false,
        infinite: true,
        vertical: true,
        responsive: [
            {
                breakpoint: 1199,
                settings: {
                    vertical: true,
                    infinite: true,
                    mobileFirst: true,
                    slidesToShow: 4,
                    slidesToScroll: 1,
                    centerMode: false,
                    focusOnSelect: false,
                    arrows: false,
                    autoplay: false,
                    swipeToSlide: true
                }
            },
            {
                breakpoint: 768,
                settings: {
                    vertical: false,
                    infinite: true,
                    mobileFirst: true,
                    slidesToShow: 4,
                    slidesToScroll: 1,
                    centerMode: false,
                    focusOnSelect: false,
                    arrows: false,
                    autoplay: false,
                    swipeToSlide: true
                }
            }
        ]
    }); 
    
    $('.related_product #collection_products_list').slick({
        autoplay: false,
        arrows: false,
        slidesToShow: 4,
        slidesToScroll: 1,
        prevArrow:"<img class='a-left control-c prev slick-prev' src='https://cdn.shopify.com/s/files/1/0098/8915/3081/files/icon-arrow-left.svg?v=1600149723'>",
        nextArrow:"<img class='a-right control-c next slick-next' src='https://cdn.shopify.com/s/files/1/0098/8915/3081/files/icon-arrow-right.svg?v=1600149723'>",
        responsive: [
            {
                breakpoint: 992,
                settings: {
                    infinite: true,
                    slidesToShow: 3,
                    slidesToScroll: 1,
                    arrows: true,
                    mobileFirst: true,
                    centerMode: false,
                    infinite: true
                }
            },
            {
                breakpoint: 767,
                settings: {
                    infinite: true,
                    slidesToShow: 2,
                    slidesToScroll: 1,
                    arrows: true,
                    mobileFirst: true,
                    centerMode: false,
                    infinite: true
                }
            }
        ]
    })


    // Initializing nice select
    $('select').niceSelect();

    let sortingCollectionName = $('.dropdown button');
    //console.log(sortingCollectionName.text());
    
    $('.dropdown').click(function name(event) {
        console.log("Clicked");
    })

    // Compact product design for opening and collapsing
    $('.compact_product_heading_title').click(function() {
        console.log("Compact product design title clicked");
        $(this).toggleClass("colorblue");
    });

    //demo 02
    //$("#demo02").animatedModal(); 


    // Colllection Page - Preview Section - Image Slider
    $('.preview_slick_slider').slick();

});



